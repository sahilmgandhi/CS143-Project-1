# CS143_Project1
CS 143 Project 1 Code: Localhost Internet Movie DataBase

Project design: 

We met all the criteria of the project, including having a nice UI design for the user to interact with, and even added features to 
sort the outputted tables and search through them for better readability. We also implemented adding information about sales and 
imdb/rotten tomatoes ratings for the movie which was not asked of from the spec, and have a 404 page to handle any bad redirects.

Project work split:

Vansh Gandhi:
Set up initial pages and connection to databases + populating some of the pages with the proper values. Worked on making the UI nicer.

Sahil Gandhi:
Populated the rest of the pages, did error testing, and worked on making the UI nicer as well.

We collaborated by using Git for version control and properly planing out the workflow as well as the layouts so that we could
finish the project in an efficient manner.

One aspect we feel that you can improve on in a team setting for better collaboration is more communication within teammates, such as
daily/bi-daily meetups to discuss progress and plans, some kind of version control or collaboration environment so that the code and 
other ideas are shared amongst group members, AND the importance that each member must be able to do their own work for the project
in order to get the grade that they deserve (ie no slackers and also no heroes who do all of the work). By incorporating all of these, 
a group can become very productive and meet all of the goals that they set out to meet! We have experience working together on projects
and using these tools, which is why we were able to meet the goals and requirements of the project!